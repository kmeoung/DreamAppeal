package com.truevalue.dreamappeal.activity;

import android.os.Bundle;

import com.truevalue.dreamappeal.R;
import com.truevalue.dreamappeal.base.BaseActivity;

public class ActivityMain extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }
}
