package com.truevalue.dreamappeal.base;

import android.app.Dialog;

public interface IODialogAlertListener {
    void setPositiveListener(Dialog dialog);

    void setNegativeListener(Dialog dialog);
}
